import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ServiceService } from './service/service.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'tic-tac-teo';
  getForm: FormGroup;
  editID: any;
  editMode: boolean = false;
  playerName : string;
  previousPlayer: string;
  constructor( public gameService: ServiceService,
    private fb: FormBuilder
    ){
  
  }
  resetGame(){
    this.gameService.newGame()
   
  }
  ngOnInit() {
    this.initForm();
  }

  initForm(){
    this.getForm = this.fb.group({
      playerName : ['']
    })
  }

  edit(i, player){
    this.previousPlayer = this.gameService.players[i]
    this.editMode = true;
    this.editID = i;
    this.playerName = player
  }
  cancel(){
    this.editMode = false;
  }

  onSubmit(){
    let val2 = this.getForm.value.playerName;
    this.gameService.players[this.editID] = val2;
    this.editMode = false;
    for( let i=0; i<this.gameService.board.length; i++){
      if (this.gameService.board[i].state === this.previousPlayer){
        this.gameService.board[i].state = val2;
      }
    }
    if(this.gameService.win === val2){
      this.gameService.win = val2
      console.log("data", this.gameService.win);
    }
  }

 
 
}
